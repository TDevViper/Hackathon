import React from 'react';
import DashboardControls from './DashboardControls';

export default function DashboardHeader({ onSearch, onExport, onRefresh, refreshTimer }) {
  return (
    <header className="sticky top-0 z-50 bg-slate-950/80 backdrop-blur border-b border-slate-800 no-print">
      <div className="max-w-[1600px] mx-auto px-6 py-3 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center text-sm shadow-lg shadow-blue-500/30">⚡</div>
          <span className="font-black text-base tracking-tight text-white">Supply<span className="text-blue-400">Guard</span></span>
          <span className="hidden sm:flex items-center gap-1.5 text-[10px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            LIVE
          </span>
        </div>
        <div className="flex-1 max-w-sm">
          <input
            type="text"
            placeholder="Search events, countries..."
            onChange={e => onSearch && onSearch(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-2 text-sm text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500 transition-colors"
          />
        </div>
        <DashboardControls onRefresh={onRefresh} />
      </div>
    </header>
  );
}
